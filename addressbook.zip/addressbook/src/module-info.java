/**
 * 
 */
/**
 * @author rajiv.yadav
 *
 */
module addressbook {
}