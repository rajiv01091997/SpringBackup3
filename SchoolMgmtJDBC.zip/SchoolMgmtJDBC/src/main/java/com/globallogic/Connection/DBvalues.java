package com.globallogic.Connection;

public interface DBvalues {
public static final String DRIVER_ADDRESS="com.mysql.cj.jdbc.Driver";
public static final String URL="jdbc:mysql://localhost:3306/StudentMgmt";
public static final String USERNAME="root";
public static final String PASSWORD="Jaibholeki1@";
}
